# mrg-dual-auth-keytab

Configures OUD+AD coexistence (krb5/sssd/authselect/sudoers) and joins RHEL
8/9/10 servers to PNC Active Directory. This variant sources a pre-built,
static keytab file (committed under `files/`) instead of resolving a
password from CyberArk at runtime - useful while the CyberArk/AAP
credential-type plumbing in the sibling `mrg-dual-auth-cyberark` role is
still being sorted out, or as a fallback path. Idempotent and safe to rerun
for troubleshooting.

## Layout

```
mrg-dual-auth-keytab/
  files/        static config files + the .j2 templates + the keytab file
  meta/         placeholder only (main.yml: "---")
  playbooks/    example/convenience entry point (main.yml)
  tasks/        all task logic, entry point is tasks/main.yml
  vars/         vars/main.yml - all role variables
  README.md
```

## The keytab files

`vars/main.yml`'s `mrg_dual_auth_static_keytab_filename_map` names four
separate files, one per environment, each holding just that environment's
single bind account:

| Environment | File                  | Bind account |
|--------------|------------------------|---------------|
| rnd          | `files/ad-bind-rnd.dat`  | XAAMMRAS    |
| uat          | `files/ad-bind-uat.dat`  | XAAMMUAS    |
| qa           | `files/ad-bind-qa.dat`   | XAAMMQAS    |
| prod         | `files/ad-bind-prod.dat` | XAAMMPAS    |

None of them are named with a `.keytab` extension since some orgs' GitHub
policies flag that extension - but each file format is identical to a real
keytab, just under a different name. `tasks/stage_static_keytab.yml` copies
whichever one matches the current host's environment to a tmpfs location at
runtime and `kinit`s with it directly - no `ktutil` step runs as part of
this role at all, exactly like the original RPM's pre-staged
`/var/tmp/join_ad/<adUser>.keytab` approach.

Build each one separately with the same single-account sequence you
already have, e.g. for prod:

```
ktutil
addent -password -p XAAMMPAS@PROD.PNCINT.NET -k <kvno> -e aes128-cts-hmac-sha1-96 -s "PROD.PNCINT.NETXAAMMPAS"
addent -password -p XAAMMPAS@PROD.PNCINT.NET -k <kvno> -e aes256-cts-hmac-sha1-96 -s "PROD.PNCINT.NETXAAMMPAS"
wkt ad-bind-prod.dat
quit
```

Repeat for the other three accounts/realms with their own current `kvno`
(don't assume it's the same across accounts - your own QA/UAT examples
earlier used `-k 1` and `-k 2` respectively). Drop each result at the path
in the table above, `chmod 600` it, and treat all four with the same care
as any other credential material (restricted repo access, rotate when a
password changes, etc.) - removing the `.keytab` extension avoids a GitHub
policy trip-wire, it doesn't make the files any less sensitive. Honest
placeholder stubs (not real keytabs) are currently in their place so the
role tree is complete - swap in the real files before relying on this.

## Bitbucket + AAP setup

Push this folder's contents **at the repo root** (`files/`, `meta/`,
`playbooks/`, `tasks/`, `vars/`, `README.md` directly at top level - no
extra nesting). Sync that repo as an AAP Project, then in the Job Template
set "Playbook" to `playbooks/main.yml`. That part works exactly as you'd
expect - the dropdown/field just needs a path to a `.yml` file inside the
project, and AAP will run it as `ansible-playbook playbooks/main.yml` from
the project root.

**The part that wouldn't have worked**: `playbooks/main.yml` no longer uses
`roles: - role: mrg-dual-auth-keytab`. Ansible only resolves a role name to
a directory via a `roles/` folder *adjacent to the playbook file itself*
(i.e. it would have looked for `playbooks/roles/mrg-dual-auth-keytab/`)
plus a couple of global system paths - it never checks the project root,
even though `tasks/`, `vars/`, and `files/` live there. I confirmed this
concretely: pointing `ansible-playbook` at a bare `roles:` reference with
no matching `roles/` folder fails with `The role '...' was not found in:
<playbook_dir>/roles:~/.ansible/roles:/usr/share/ansible/roles:/etc/ansible/roles`
- the project root is never in that list. So as originally written, this
would have failed the moment AAP ran it.

The fix: `playbooks/main.yml` now imports `vars/main.yml` and
`tasks/main.yml` directly using Ansible's `playbook_dir` magic variable
(the absolute directory of the currently-running top-level playbook, stable
for the whole run): `"{{ playbook_dir }}/../vars/main.yml"` and
`"{{ playbook_dir }}/../tasks/main.yml"`. Every `template:`/`copy:` task in
`tasks/configure_auth.yml` and `tasks/stage_static_keytab.yml` was updated
the same way (e.g. `"{{ playbook_dir }}/../files/krb5.conf.j2"` instead of
the bare `files/krb5.conf.j2`), since those don't get any role-aware path
search either once `roles:` is out of the picture. This is no longer a
"role" in the formal Ansible sense - just a playbook plus imported task
files - which fits fine with your "doesn't have to be the ansible-lint way"
call, and avoids relying on any of Ansible's less-obvious path search-order
behavior. I tested this for real (not just `--syntax-check`, which doesn't
actually exercise template/copy file lookups): ran the actual
`playbooks/main.yml` from this repo in `--check` mode and confirmed every
file reference, including the four per-environment keytab files, resolves
and reads correctly.

(There's an alternative, more "idiomatic Ansible" fix: nest this content
under `playbooks/roles/mrg-dual-auth-keytab/{tasks,vars,files,meta}` so the
standard role mechanism works as-is. I didn't go that way since it moves
your requested top-level folders to a different nesting level for no real
benefit here - happy to switch if you'd rather have a "real" role.)

## Quick start (local testing, outside AAP)

```bash
ansible-playbook playbooks/main.yml -i your-host, -e mrg_dual_auth_target_env=qa
```

## Environment detection

Same as the CyberArk variant: `mrg_dual_auth_target_env` is derived from
the 5th character of the short hostname, or override with
`-e mrg_dual_auth_target_env=qa`.

## Tags

Identical tag behavior to `mrg-dual-auth-cyberark`:

| Tags                  | When it runs                          | What it does |
|------------------------|---------------------------------------|--------------|
| *(default, no tags)*  | always                                | facts + preflight + health check + configure + join-if-needed |
| `configure`, `auth_config` | always (unless filtered out)     | reapply sssd/krb5/authselect/sudoers config only |
| `join`                | only if not already healthily joined  | the AD join step |
| `rejoin`               | **only with `--tags rejoin`**         | leave AD, remove the keytab, rejoin cleanly |
| `leave_ad`             | **only with `--tags leave_ad`**       | full decommission: leave AD, restore pre-join backups, return to OUD-only |

## What's different from mrg-dual-auth-cyberark

Only the keytab-acquisition step: `tasks/stage_static_keytab.yml` (copy +
`kinit`) replaces `tasks/build_transient_keytab.yml` (CyberArk-resolved
password + `ktutil` + `kinit`). `join_ad.yml`, `rejoin.yml`, `leave_ad.yml`,
`configure_auth.yml`, and every template/static file are otherwise
identical between the two roles. There's no `mrg_dual_auth_password`
variable in this variant at all - nothing to resolve at runtime.

## Other previously-flagged items (still open, same as the CyberArk variant)

- `[domain/default]` → `[domain/OUD]` rename in `configure_auth.yml` is
  unverified against a real pre-existing OUD-only `sssd.conf`.
- `55-pncad.conf`'s dead `domains=` line was generalized from a hardcoded
  `uat` to `{{ mrg_dual_auth_domain }}` - flag if that's wrong.
- `krb5.conf.prod`'s capaths typos (`PRODR.PNCINT.COM`, `PROD.PNCINT.COM`)
  preserved verbatim - live Kerberos trust config, not "fixed" silently.
- `files/rbin/*` scripts are placeholder stubs - swap in real content.
- `files/login-access.conf.j2` is an honest placeholder (real heredoc
  content was never shared) and is not deployed by `configure_auth.yml`.
