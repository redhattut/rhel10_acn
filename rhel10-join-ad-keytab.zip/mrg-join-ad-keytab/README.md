# mrg-join-ad-keytab

Configures OUD+AD coexistence (krb5/sssd/authselect/sudoers) and joins RHEL
8/9/10 servers to PNC Active Directory. This variant sources a pre-built,
static keytab file (committed under `files/`) instead of resolving a
password from CyberArk at runtime - useful while the CyberArk/AAP
credential-type plumbing in the sibling `mrg-join-ad-cyberark` role is
still being sorted out, or as a fallback path. Idempotent and safe to rerun
for troubleshooting.

## Layout

```
mrg-join-ad-keytab/
  files/        static config files + the .j2 templates + the keytab file
  meta/         placeholder only (main.yml: "---")
  playbooks/    example/convenience entry point (main.yml)
  tasks/        all task logic, entry point is tasks/main.yml
  vars/         vars/main.yml - all role variables
  README.md
```

## The keytab files

`vars/main.yml`'s `dual_auth_static_keytab_filename_map` names four
separate files, one per environment, each holding just that environment's
single bind account:

| Environment | File                  | Bind account |
|--------------|------------------------|---------------|
| rnd          | `files/ad-bind-rnd.dat`  | XAAMMRAS    |
| uat          | `files/ad-bind-uat.dat`  | XAAMMUAS    |
| qa           | `files/ad-bind-qa.dat`   | XAAMMQAS    |
| prod         | `files/ad-bind-prod.dat` | XAAMMPAS    |

None of them are named with a `.keytab` extension since some orgs' GitHub
policies flag that extension - but each file format is identical to a real
keytab, just under a different name. `tasks/stage_static_keytab.yml` copies
whichever one matches the current host's environment to a tmpfs location at
runtime and `kinit`s with it directly - no `ktutil` step runs as part of
this role at all, exactly like the original RPM's pre-staged
`/var/tmp/join_ad/<adUser>.keytab` approach.

Build each one separately with the same single-account sequence you
already have, e.g. for prod:

```
ktutil
addent -password -p XAAMMPAS@PROD.PNCINT.NET -k <kvno> -e aes128-cts-hmac-sha1-96 -s "PROD.PNCINT.NETXAAMMPAS"
addent -password -p XAAMMPAS@PROD.PNCINT.NET -k <kvno> -e aes256-cts-hmac-sha1-96 -s "PROD.PNCINT.NETXAAMMPAS"
wkt ad-bind-prod.dat
quit
```

Repeat for the other three accounts/realms with their own current `kvno`
(don't assume it's the same across accounts - your own QA/UAT examples
earlier used `-k 1` and `-k 2` respectively). Drop each result at the path
in the table above, `chmod 600` it, and treat all four with the same care
as any other credential material (restricted repo access, rotate when a
password changes, etc.) - removing the `.keytab` extension avoids a GitHub
policy trip-wire, it doesn't make the files any less sensitive. Honest
placeholder stubs (not real keytabs) are currently in their place so the
role tree is complete - swap in the real files before relying on this.

## Bitbucket + AAP setup

Push this folder's contents **at the repo root** (`files/`, `meta/`,
`playbooks/`, `tasks/`, `vars/`, `README.md` directly at top level - no
extra nesting). Sync that repo as an AAP Project, then in the Job Template
set "Playbook" to `playbooks/main.yml`. That part works exactly as you'd
expect - the dropdown/field just needs a path to a `.yml` file inside the
project, and AAP will run it as `ansible-playbook playbooks/main.yml` from
the project root.

**The part that wouldn't have worked**: `playbooks/main.yml` no longer uses
`roles: - role: mrg-join-ad-keytab`. Ansible only resolves a role name to
a directory via a `roles/` folder *adjacent to the playbook file itself*
(i.e. it would have looked for `playbooks/roles/mrg-join-ad-keytab/`)
plus a couple of global system paths - it never checks the project root,
even though `tasks/`, `vars/`, and `files/` live there. I confirmed this
concretely: pointing `ansible-playbook` at a bare `roles:` reference with
no matching `roles/` folder fails with `The role '...' was not found in:
<playbook_dir>/roles:~/.ansible/roles:/usr/share/ansible/roles:/etc/ansible/roles`
- the project root is never in that list. So as originally written, this
would have failed the moment AAP ran it.

The fix: `playbooks/main.yml` now imports `vars/main.yml` and
`tasks/main.yml` directly using Ansible's `playbook_dir` magic variable
(the absolute directory of the currently-running top-level playbook, stable
for the whole run): `"{{ playbook_dir }}/../vars/main.yml"` and
`"{{ playbook_dir }}/../tasks/main.yml"`. Every `template:`/`copy:` task in
`tasks/configure_auth.yml` and `tasks/stage_static_keytab.yml` was updated
the same way (e.g. `"{{ playbook_dir }}/../files/krb5.conf.j2"` instead of
the bare `files/krb5.conf.j2`), since those don't get any role-aware path
search either once `roles:` is out of the picture. This is no longer a
"role" in the formal Ansible sense - just a playbook plus imported task
files - which fits fine with your "doesn't have to be the ansible-lint way"
call, and avoids relying on any of Ansible's less-obvious path search-order
behavior. I tested this for real (not just `--syntax-check`, which doesn't
actually exercise template/copy file lookups): ran the actual
`playbooks/main.yml` from this repo in `--check` mode and confirmed every
file reference, including the four per-environment keytab files, resolves
and reads correctly.

(There's an alternative, more "idiomatic Ansible" fix: nest this content
under `playbooks/roles/mrg-join-ad-keytab/{tasks,vars,files,meta}` so the
standard role mechanism works as-is. I didn't go that way since it moves
your requested top-level folders to a different nesting level for no real
benefit here - happy to switch if you'd rather have a "real" role.)

## Lifecycle action (the AAP Survey control) and tags

The thing that picks "normal run" vs. forced rejoin vs. full decommission
is `dual_auth_lifecycle_action` (default `"configure"`), a plain
extra_var - **not** an Ansible tag. I confirmed this against Red Hat's own
docs across every AAP/Controller/AWX/Tower version going back to 3.1:
Survey questions always become `extra_vars`; there is no mechanism for a
Survey answer to populate the Job Template's native "Job Tags" field
directly. ("When you pass survey variables, they are passed as extra
variables (extra_vars) within automation controller.") That field does
exist and can be set via its own separate "Prompt on Launch" toggle, but
it's a raw freeform text box on the Launch screen, not a clean
multiple-choice button - not what you want for an operator-facing choice.

**AAP Survey setup** (on the Job Template's Survey tab):
- Question: "Lifecycle action"
- Answer type: Multiple Choice (single select)
- Answer options, one per line: `configure`, `rejoin`, `leave_ad`
- Variable name: `dual_auth_lifecycle_action`
- Default answer: `configure`

(The options shown to the operator are literally what gets passed as the
var's value, so I kept them as the literal values for simplicity. If you'd
rather show friendlier labels like "Force rejoin", add a small
`set_fact` translation step at the top of `tasks/main.yml` mapping the
friendly label to the internal value - happy to add that if wanted.)

Allowed values:

| `dual_auth_lifecycle_action` | What it does |
|---|---|
| `configure` (default) | facts + preflight + health check + configure + join-if-needed |
| `rejoin` | all of the above, then forced leave-then-rejoin |
| `leave_ad` | all of the above, then full decommission (leave AD, restore pre-join backups) |

An early `assert` in `preflight.yml` fails fast with a clear message if
this is set to anything else (typo protection).

Plain Ansible tags are still attached to the underlying tasks too, purely
as a CLI convenience for ad-hoc partial reruns (`--tags configure` to just
reapply config, `--tags join` to just attempt the join) - they are not
needed to trigger rejoin/leave_ad, and aren't how AAP should drive this.

**One important wrinkle found via real testing**: `configure_auth.yml` is
tagged both `configure` *and* `join`, deliberately. The AD join is
meaningless without the sssd/krb5/conf.d config `configure_auth.yml` lays
down first (it's what creates the `[domain/OUD]` coexistence config and
the krb5.conf this environment needs) - so `--tags join` alone must still
apply `configure_auth.yml`, not skip straight to the join itself. This
was a real bug: running `--tags join` against a freshly-cleaned host
completed without error but left `/etc/krb5.conf` missing, `/etc/sssd/conf.d/`
empty, and `sssd.conf` still showing `[domain/default]` instead of
`[domain/OUD]` - because `configure_auth.yml` was being skipped entirely
by the tag filter. Fixed by adding `join` to its tag list. The reverse
isn't true: `--tags configure` alone still does *not* also run
`join_ad.yml` - reapplying config shouldn't automatically also attempt a
domain join. Confirmed with `--list-tasks --tags join` /
`--list-tasks --tags configure` against the actual playbook.

**The other bug found via real testing**: the "is krb5.conf safe to
overwrite" preflight check (the one that compares `/etc/krb5.conf`'s
checksum against a list of known pristine RHEL-default checksums) was
failing on hosts that were *already* correctly OUD+AD-joined, and also
when explicitly running `--tags rejoin`. Both are false failures: an
already-joined host's krb5.conf is *our own* templated output (env-specific
realm baked in), not the pristine OS default, so comparing it against the
pristine-default checksum list was always going to fail there - that
check was never meant to apply once we know the host is already healthy.
Likewise, an explicit rejoin/leave_ad is the operator declaring intent to
override regardless of current state, so the check shouldn't block that
either. Fixed by moving the check from `preflight.yml` into
`health_check.yml` (after `dual_auth_healthy` is actually known) and
adding `dual_auth_healthy or dual_auth_lifecycle_action in
['rejoin', 'leave_ad']` ahead of the existing checksum/absence check. The
original safety guard - refusing to overwrite an unrecognized krb5.conf on
a genuinely unknown, unhealthy host doing a normal `configure` run - still
works exactly as before; I unit-tested all three branches (healthy,
forced rejoin, and genuinely-unknown-and-unhealthy) directly against the
assert logic to confirm.

## Dynamic host input (optional, instead of an AAP Inventory)

`playbooks/main.yml` has an optional first play that builds an ad-hoc
`dynamic_group` from a Survey textarea variable called
`dynamic_hosts_input` (one hostname per line), for AAP setups where
operators paste in a host list rather than maintaining a pre-populated
Inventory. It's fully backward compatible: if `dynamic_hosts_input` isn't
supplied, that play does nothing and the second play falls back to
`hosts: all` (the normal Inventory-driven flow) via a Jinja-templated
`hosts:` field. Blank/whitespace-only lines are trimmed and filtered out
(the version you showed me didn't do this, which would otherwise try to
add a host literally named `""` if the textarea had a trailing newline).

**AAP Survey setup**, if you want to use this:
- Question: anything you like, e.g. "Target hosts (one per line)"
- Answer type: Textarea
- Variable name: `dynamic_hosts_input`
- Required: optional (leave unrequired to keep the Inventory-driven
  fallback usable)

## Quick start (local testing, outside AAP)

```bash
ansible-playbook playbooks/main.yml -i your-host, -e dual_auth_target_env=qa
```

## Environment detection

Same as the CyberArk variant: `dual_auth_target_env` is derived from
the 5th character of the short hostname, or override with
`-e dual_auth_target_env=qa`.

## What's different from mrg-join-ad-cyberark

Only the keytab-acquisition step: `tasks/stage_static_keytab.yml` (copy +
`kinit`) replaces `tasks/build_transient_keytab.yml` (CyberArk-resolved
password + `ktutil` + `kinit`). `join_ad.yml`, `rejoin.yml`, `leave_ad.yml`,
`configure_auth.yml`, and every template/static file are otherwise
identical between the two roles. There's no `dual_auth_password`
variable in this variant at all - nothing to resolve at runtime.

## Other previously-flagged items (still open, same as the CyberArk variant)

- `[domain/default]` → `[domain/OUD]` rename in `configure_auth.yml` is
  unverified against a real pre-existing OUD-only `sssd.conf`.
- `55-pncad.conf`'s dead `domains=` line was generalized from a hardcoded
  `uat` to `{{ dual_auth_domain }}` - flag if that's wrong.
- `krb5.conf.prod`'s capaths typos (`PRODR.PNCINT.COM`, `PROD.PNCINT.COM`)
  preserved verbatim - live Kerberos trust config, not "fixed" silently.
- `files/rbin/*` scripts are placeholder stubs - swap in real content.
- `files/login-access.conf.j2` is an honest placeholder (real heredoc
  content was never shared) and is not deployed by `configure_auth.yml`.
